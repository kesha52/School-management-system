﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace School_Management
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            Display();
            Display1();
            Display2();
            Display3();
        }

        private void Display()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TBFMMSU\MSSQLSERVER01;Initial Catalog=schooldb;Integrated Security=True");
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM studenttb", con);
            Int32 count = Convert.ToInt32(cmd.ExecuteScalar());
            if (count > 0)
            {
                lblCount.Text = Convert.ToString(count.ToString());
            }
            else
            {
                lblCount.Text = "0";
            }

            con.Close();

        }

        private void Display1()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TBFMMSU\MSSQLSERVER01;Initial Catalog=schooldb;Integrated Security=True");
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM subjecttb", con);
            Int32 count = Convert.ToInt32(cmd.ExecuteScalar());
            if (count > 0)
            {
                lblCount1.Text = Convert.ToString(count.ToString());
            }
            else
            {
                lblCount1.Text = "0";
            }

            con.Close();

        }

        private void Display2()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TBFMMSU\MSSQLSERVER01;Initial Catalog=schooldb;Integrated Security=True");
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM teachertb", con);
            Int32 count = Convert.ToInt32(cmd.ExecuteScalar());
            if (count > 0)
            {
                lblCount2.Text = Convert.ToString(count.ToString());
            }
            else
            {
                lblCount2.Text = "0";
            }

            con.Close();

        }

        private void Display3()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TBFMMSU\MSSQLSERVER01;Initial Catalog=schooldb;Integrated Security=True");
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM attendencetb", con);
            Int32 count = Convert.ToInt32(cmd.ExecuteScalar());
            if (count > 0)
            {
                lblCount3.Text = Convert.ToString(count.ToString());
            }
            else
            {
                lblCount3.Text = "0";
            }

            con.Close();

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
