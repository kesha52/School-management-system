﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace School_Management
{
    public partial class Score : Form
    {
        public Score()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnCala_Click(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double maths, science, english, total, average;
            string grade;

            // Input validation to ensure only numeric values are allowed
            if (!double.TryParse(txtMaths.Text, out maths) ||
                !double.TryParse(txtScience.Text, out science) ||
                !double.TryParse(txtEnglish.Text, out english))
            {
                MessageBox.Show("Please enter valid numeric values for Maths, Science, and English.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Calculating total and average
            total = maths + science + english;
            txtTotal.Text = total.ToString();

            average = Math.Round(total / 3, 2); // Rounds average to 2 decimal places
            txtAverage.Text = average.ToString("F2"); // Formats with exactly 2 decimal places

            // Determining grade based on average
            if (average >= 75)
            {
                grade = "A";
            }
            else if (average >= 65)
            {
                grade = "B";
            }
            else if (average >= 55)
            {
                grade = "C";
            }
            else if (average >= 45)
            {
                grade = "D";
            }
            else
            {
                grade = "F";
            }

            txtGrade.Text = grade;
        }


        private void btnDisplay_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TBFMMSU\MSSQLSERVER01;Initial Catalog=schooldb;Integrated Security=True");
            con.Open();
            SqlCommand cnn = new SqlCommand("select * from SGrade", con);
            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            txtStudentName.Text = "";
            txtMaths.Text = "";
            txtScience.Text = "";
            txtEnglish.Text = "";
            txtTotal.Text = "";
            txtAverage.Text = "";
            txtGrade.Text = "";
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Score_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TBFMMSU\MSSQLSERVER01;Initial Catalog=schooldb;Integrated Security=True");
            con.Open();
            SqlCommand cnn = new SqlCommand("select * from SGrade", con);
            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TBFMMSU\MSSQLSERVER01;Initial Catalog=schooldb;Integrated Security=True");
            con.Open();

            SqlCommand cnn = new SqlCommand("insert into SGrade values(@studentname,@Maths,@Science,@English,@Total,@Average,@Grade)", con);
            cnn.Parameters.AddWithValue("@StudentName", txtStudentName.Text);
            cnn.Parameters.AddWithValue("@Maths", txtMaths.Text);
            cnn.Parameters.AddWithValue("@Science", txtScience.Text);
            cnn.Parameters.AddWithValue("@English", txtEnglish.Text);
            cnn.Parameters.AddWithValue("@Total", txtTotal.Text);
            cnn.Parameters.AddWithValue("@Average", txtAverage.Text);
            cnn.Parameters.AddWithValue("@Grade", txtGrade.Text);
            cnn.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Saved Successfully", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void txtTotal_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
